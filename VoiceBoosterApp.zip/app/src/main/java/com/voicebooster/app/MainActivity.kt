package com.voicebooster.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var prefs: SharedPreferences
    private lateinit var injectJs: String
    private var scriptHandler: ScriptHandler? = null
    private var pendingPermission: PermissionRequest? = null

    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))

        prefs = getSharedPreferences("vb", MODE_PRIVATE)
        injectJs = assets.open("inject.js").bufferedReader().use { it.readText() }

        web = findViewById(R.id.web)
        setupWebView()
        registerScript()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        web.loadUrl(prefs.getString("url", MESSENGER) ?: MESSENGER)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = desktopUa
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                // Fallback for old WebView versions without document-start scripts.
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    view.evaluateJavascript(initScript(), null)
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (url != null) prefs.edit().putString("url", url).apply()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { handlePermission(request) }
            }
        }
    }

    // ---- Injection ----

    private fun settingsJson(): String = JSONObject()
        .put("enabled", prefs.getBoolean("enabled", true))
        .put("micGain", prefs.getFloat("mic", 3f).toDouble())
        .put("callGain", prefs.getFloat("call", 2f).toDouble())
        .put("preset", prefs.getString("preset", "clear"))
        .toString()

    private fun initScript(): String = "window.__VB_INIT=${settingsJson()};\n$injectJs"

    private fun registerScript() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            scriptHandler?.remove()
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, initScript(), setOf("*"))
        }
    }

    private fun pushSettings() {
        web.evaluateJavascript(
            "window.postMessage({__vb:'settings',value:${settingsJson()}},'*')", null
        )
        registerScript() // so the next page load starts with the new values
    }

    // ---- Mic / camera permission ----

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun handlePermission(req: PermissionRequest) {
        val needed = mutableListOf<String>()
        for (r in req.resources) {
            if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE) needed.add(Manifest.permission.RECORD_AUDIO)
            if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE) needed.add(Manifest.permission.CAMERA)
        }
        val missing = needed.filter { !granted(it) }
        if (missing.isEmpty()) {
            req.grant(req.resources)
        } else {
            pendingPermission = req
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val req = pendingPermission ?: return
        pendingPermission = null
        val ok = req.resources.filter { r ->
            when (r) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> granted(Manifest.permission.RECORD_AUDIO)
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> granted(Manifest.permission.CAMERA)
                else -> false
            }
        }
        if (ok.isEmpty()) req.deny() else req.grant(ok.toTypedArray())
    }

    // ---- Menu and panel ----

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_boost -> showPanel()
            R.id.action_messenger -> web.loadUrl(MESSENGER)
            R.id.action_whatsapp -> web.loadUrl("https://web.whatsapp.com/")
            R.id.action_telegram -> web.loadUrl("https://web.telegram.org/a/")
            R.id.action_instagram -> web.loadUrl("https://www.instagram.com/direct/inbox/")
            R.id.action_reload -> web.reload()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun showPanel() {
        val dialog = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.panel, null)
        val sw = v.findViewById<SwitchMaterial>(R.id.swEnabled)
        val sbMic = v.findViewById<SeekBar>(R.id.sbMic)
        val sbCall = v.findViewById<SeekBar>(R.id.sbCall)
        val tvMic = v.findViewById<TextView>(R.id.tvMic)
        val tvCall = v.findViewById<TextView>(R.id.tvCall)
        val btnClear = v.findViewById<MaterialButton>(R.id.btnClear)
        val btnMax = v.findViewById<MaterialButton>(R.id.btnMax)

        fun mic() = prefs.getFloat("mic", 3f)
        fun call() = prefs.getFloat("call", 2f)

        fun refresh() {
            sw.isChecked = prefs.getBoolean("enabled", true)
            sbMic.progress = ((mic() - 1f) * 2f).toInt()
            sbCall.progress = ((call() - 1f) * 4f).toInt()
            tvMic.text = "Mic gain: ${mic()}x"
            tvCall.text = "Call volume: ${call()}x"
            val preset = prefs.getString("preset", "clear")
            btnClear.strokeWidth = if (preset == "clear") 4 else 1
            btnMax.strokeWidth = if (preset == "max") 4 else 1
        }

        fun save(block: SharedPreferences.Editor.() -> Unit) {
            prefs.edit().apply(block).apply()
            refresh()
            pushSettings()
        }

        refresh()
        sw.setOnCheckedChangeListener { _, on ->
            if (on != prefs.getBoolean("enabled", true)) save { putBoolean("enabled", on) }
        }
        btnClear.setOnClickListener {
            save { putString("preset", "clear"); putFloat("mic", 3f); putFloat("call", 2f) }
        }
        btnMax.setOnClickListener {
            save { putString("preset", "max"); putFloat("mic", 7f); putFloat("call", 4f) }
        }
        sbMic.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) save { putFloat("mic", 1f + p * 0.5f) }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        sbCall.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) save { putFloat("call", 1f + p * 0.25f) }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        dialog.setContentView(v)
        dialog.show()
    }

    companion object {
        private const val MESSENGER = "https://www.messenger.com/"
    }
}
