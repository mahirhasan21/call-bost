// Injected into every page before it loads. Boosts outgoing mic and incoming call audio.
(() => {
  if (window.__voiceBooster) return;

  const state = { enabled: true, micGain: 3, callGain: 2, preset: "clear" };
  Object.assign(state, window.__VB_INIT || {});

  const mics = [];
  const calls = [];
  const seen = new WeakSet();
  let ctx = null;

  const getCtx = () => {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    return ctx;
  };

  // The limiter stops peaks from clipping, which is what makes boosted audio crackle.
  const makeLimiter = (c, strong) => {
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = strong ? -12 : -6;
    comp.knee.value = strong ? 0 : 6;
    comp.ratio.value = strong ? 20 : 12;
    comp.attack.value = 0.003;
    comp.release.value = strong ? 0.2 : 0.12;
    return comp;
  };

  const apply = () => {
    const strong = state.preset === "max";
    const on = state.enabled;
    mics.forEach((m) => {
      m.gain.gain.value = on ? state.micGain : 1;
      m.comp.threshold.value = strong ? -12 : -6;
      m.comp.ratio.value = strong ? 20 : 12;
      m.hp.frequency.value = on ? 80 : 10;
    });
    calls.forEach((k) => {
      k.gain.gain.value = on ? state.callGain : 1;
      k.comp.threshold.value = strong ? -12 : -6;
      k.comp.ratio.value = strong ? 20 : 12;
    });
  };

  // Outgoing mic
  const md = navigator.mediaDevices;
  if (md && md.getUserMedia) {
    const orig = md.getUserMedia.bind(md);
    md.getUserMedia = async (constraints) => {
      const stream = await orig(constraints);
      try {
        if (!stream.getAudioTracks().length) return stream;
        const c = getCtx();
        const src = c.createMediaStreamSource(stream);
        const hp = c.createBiquadFilter();
        hp.type = "highpass";
        const gain = c.createGain();
        const comp = makeLimiter(c, state.preset === "max");
        const dest = c.createMediaStreamDestination();
        src.connect(hp).connect(gain).connect(comp).connect(dest);
        mics.push({ gain, comp, hp });
        apply();
        return new MediaStream([
          ...dest.stream.getAudioTracks(),
          ...stream.getVideoTracks(),
        ]);
      } catch (e) {
        console.warn("[Voice Booster] mic boost unavailable", e);
        return stream;
      }
    };
  }

  // Incoming call audio
  const attach = (el) => {
    if (seen.has(el)) return;
    seen.add(el);
    try {
      const c = getCtx();
      const src = c.createMediaElementSource(el);
      const gain = c.createGain();
      const comp = makeLimiter(c, state.preset === "max");
      src.connect(gain).connect(comp).connect(c.destination);
      calls.push({ gain, comp });
      apply();
    } catch (e) {
      console.warn("[Voice Booster] call boost unavailable", e);
    }
  };

  const origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    if (this.srcObject instanceof MediaStream) attach(this);
    return origPlay.apply(this, args);
  };

  // Live updates from the app's panel
  window.addEventListener("message", (ev) => {
    if (ev.source !== window || !ev.data || ev.data.__vb !== "settings") return;
    Object.assign(state, ev.data.value);
    apply();
  });

  window.__voiceBooster = true;
})();
