Voice Booster (Android)

Build the APK with GitHub Actions:
1. Make a new GitHub repository and upload everything in this folder (keep the .github folder).
2. Open the repo > Actions > "Build APK" > Run workflow (or just push to main).
3. When it finishes, open the run and download the "voice-booster-apk" artifact. Unzip it and install app-debug.apk.

Or with Android Studio: open this folder, let Gradle sync, then Build > Build APK.
